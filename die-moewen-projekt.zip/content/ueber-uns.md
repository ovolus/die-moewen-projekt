---
title: "Über uns"
---

Wir sind **Die Möwen Bremerhaven**, eine kleine, soziale und ökologische Fraktionspartei, die sich für Offenheit, Gemeinschaft und nachhaltige Stadtpolitik einsetzt.

Unsere Mitglieder kommen aus verschiedenen Bereichen – vom Hafen, aus dem Sozialwesen und aus der Jugendhilfe.

Gemeinsam gestalten wir Bremerhaven freundlich und fair.
